const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/active', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        u.id, 
        COALESCE(p.first_name, 'New') AS first_name, 
        COALESCE(p.last_name, 'Therapist') AS last_name, 
        COALESCE(tp.specialization, 'Pending Assignment') as occupation, 
        u.email, 
        null as profile_picture 
      FROM users u
      LEFT JOIN profiles p ON u.id = p.user_id
      LEFT JOIN therapist_profiles tp ON u.id = tp.user_id
      WHERE u.role = 'therapist'
      ORDER BY last_name ASC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Failed to fetch therapists:', err);
    res.status(500).json({ error: 'Failed to fetch therapists' });
  }
});

module.exports = router;
