import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, FileText } from 'lucide-react';

export default function PatientNotes() {
  const { patientId } = useParams();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 pt-32 pb-20">
      <div className="container max-w-4xl mx-auto px-4">
        <button 
          onClick={() => navigate('/therapist/dashboard')}
          className="flex items-center text-slate-500 hover:text-slate-700 transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </button>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
          <div className="flex items-center gap-4 border-b border-slate-100 pb-6 mb-6">
            <div className="h-16 w-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
              <User className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Patient Notes</h1>
              <p className="text-slate-500">ID: {patientId}</p>
            </div>
          </div>

          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">Clinical Notes & History</h3>
            <p className="text-slate-500 max-w-md mx-auto">
              This feature is currently under development. Soon you will be able to view patient history, track treatment progress, and securely save private session notes here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
